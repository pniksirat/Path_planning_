Array3d v(1,2,3), w(2,3,0);
v *= w;
cout << v << endl;
